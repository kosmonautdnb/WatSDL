del NVRBALL\*.LOG
R:\main.exe