call !copy.bat
call !clean.bat
call !make.bat
copy r:\main.exe nvrball.exe
del nvrsrc.zip
zip nvrsrc.zip nvrball.exe !*.* -r src\*.* _build\*.* sdl2\*.* libs\*.*
