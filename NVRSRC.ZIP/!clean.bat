call _BUILD\MAKEMK.BAT
cd libs
call !clean.bat
cd ..
call wmake.exe /f R:\MAKEFILE clean