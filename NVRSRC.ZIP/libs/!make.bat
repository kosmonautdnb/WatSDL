@echo off
rem @echo system dos4g > R:\LINK.LNK
@echo system pmodew > R:\LINK.LNK
@echo build errors > R:\LOGS.LOG
_BUILD\FLTMECHK.exe !MAK R:\gltest.exe
if not ERRORLEVEL 255 call _BUILD\MAKEMK.BAT
call wmake.exe /f R:\makefile /e /s /k
del obj\__main.obj
rem deltree /Y INCLUDE
rem mkdir INCLUDE
rem xcopy src\zlib\*.h INCLUDE\
rem xcopy src\libpng\*.h INCLUDE\
rem xcopy src\libjpeg\*.h INCLUDE\
