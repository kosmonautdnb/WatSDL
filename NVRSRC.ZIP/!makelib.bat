@echo off
cd libs
call !make.bat
cd ..
