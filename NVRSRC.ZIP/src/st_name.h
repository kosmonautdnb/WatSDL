#ifndef ST_NAME_H
#define ST_NAME_H

#include "state.h" // changed from:"state.h"

extern struct state st_name;

int goto_name(struct state *, struct state *, unsigned int);

#endif
