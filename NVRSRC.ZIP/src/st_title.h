#ifndef ST_TITLE_H
#define ST_TITLE_H

#include "state.h" // changed from:"state.h"

extern struct state st_title;

int load_title_background(void);

#endif
