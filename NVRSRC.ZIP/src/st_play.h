#ifndef ST_PLAY_H
#define ST_PLAY_H

extern struct state st_play_ready;
extern struct state st_play_set;
extern struct state st_play_loop;
extern struct state st_look;

#endif
