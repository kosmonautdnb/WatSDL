#ifndef ST_DONE_H
#define ST_DONE_H

#include "state.h" // changed from:"state.h"

extern struct state st_done;

#endif
