#ifndef ST_PAUSE_H
#define ST_PAUSE_H

#include "state.h" // changed from:"state.h"

extern struct state st_pause;

#endif
