#ifndef ST_HELP_H
#define ST_HELP_H

#include "state.h" // changed from:"state.h"

extern struct state st_help;
extern struct state st_help_demo;

#endif
