#ifndef ST_GOAL_H
#define ST_GOAL_H

#include "state.h" // changed from:"state.h"

extern struct state st_goal;

#endif
