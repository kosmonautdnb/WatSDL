#ifndef MAPCLIB_H
#define MAPCLIB_H

#include <setjmp.h> // changed from:<setjmp.h>

// typedef struct mapc_context *mapc_context; :mad:

int mapc_init(struct mapc_context **ctx_ptr);
void mapc_quit(struct mapc_context **ctx_ptr);

int mapc_opts(struct mapc_context *ctx, int argc, char *argv[]);

void mapc_set_src(struct mapc_context *ctx, const char *src);
void mapc_set_dst(struct mapc_context *ctx, const char *dst);

int mapc_compile(struct mapc_context *ctx);

void mapc_dump(struct mapc_context *ctx);

#endif
