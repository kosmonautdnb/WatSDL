/*
 * Copyright (C) 2003 Robert Kooima
 * Copyright (C) 2025 Jānis Rūcis
 *
 * NEVERBALL is  free software; you can redistribute  it and/or modify
 * it under the  terms of the GNU General  Public License as published
 * by the Free  Software Foundation; either version 2  of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT  ANY  WARRANTY;  without   even  the  implied  warranty  of
 * MERCHANTABILITY or  FITNESS FOR A PARTICULAR PURPOSE.   See the GNU
 * General Public License for more details.
 */

/*---------------------------------------------------------------------------*/

#include <stdio.h> // changed from:<stdio.h>
#include <setjmp.h> // changed from:<setjmp.h>
#include <stdlib.h> // changed from:<stdlib.h>

#include "FS.H" // changed from:"fs.h"
#include "MAPCLIB.H" // changed from:"mapclib.h"

int main2(int argc, char *argv[])
{
    struct mapc_context *ctx = NULL;

    if (!fs_init(argc > 0 ? argv[0] : NULL))
    {
        fprintf(stderr, "Failure to initialize virtual file system: %s\n", fs_error());
        return 1;
    }

    mapc_init(&ctx);

    if (!mapc_opts(ctx, argc, argv))
    {
        mapc_quit(&ctx);
        return 1;
    }

    if (!mapc_compile(ctx))
    {
        mapc_quit(&ctx);
        return 1;
    }

    mapc_dump(ctx);
    mapc_quit(&ctx);

    return 0;
}

