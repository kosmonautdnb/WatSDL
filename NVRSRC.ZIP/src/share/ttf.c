#include "ttf.h"
#include "charset.hpp"
#include <string.h>

TTF_Font *TTF_OpenFontRW(void *, int, int) {
  return new TTF_Font;
}

void TTF_CloseFont(TTF_Font *font) {
  delete font;
}

SDL_Result TTF_Init() {
  return SDL_OK;
}

void TTF_Quit() {
}

static int scale = 1;
void TTF_SizeUTF8(TTF_Font *font, const char *text, int *w, int *h) {
  // currently not utf8
  const char *s = text;
  int where = 0;
  int hhere = 0;
  int wmax = 0;
  int hmax = 0;
  while(*s!=0x00) {
    if (*s == '\n') {
      where = 0;
      hhere = hmax;
      s++;
      continue;
    }
    Letter* l=getLetter(*s);
    where += l->preAddX+l->width+l->postAddX+1;
    wmax = where>wmax?where:wmax;
    hmax = (hhere+l->preAddY+l->height+l->postAddY)>hmax?(hhere+l->preAddY+l->height+l->postAddY):hmax;
    s++;
  }
  *w = wmax*scale;
  *h = hmax*scale;
}

SDL_Surface *TTF_RenderUTF8_Blended(TTF_Font *font,const char *text, SDL_Color col) {
  int w,h;
  TTF_SizeUTF8(font,text,&w,&h);
  SDL_Surface *r = SDL_CreateRGBSurface(0, w, h, 32, 0, 0, 0, 0);
  memset(r->pixels,0,w*h*4);

  const char *s = text;
  int where = 0;
  int hhere = 0;
  int wmax = 0;
  int hmax = 0;
  unsigned int cl = *((unsigned int*)&col);
  while(*s!=0x00) {
    if (*s == '\n') {
      where = 0;
      hhere = hmax;
      s++;
      continue;
    }
    Letter* l=getLetter(*s);
    for (int y = 0; y < l->height*scale; y++) {
      for (int x = 0; x < l->width*scale; x++) {
        char c = l->bitmap[(x/scale)+(y/scale)*l->width];
        if (c!='0')
          ((unsigned int *)r->pixels)[(x+(l->preAddX+where)*scale)+(y+(l->preAddY+hhere)*scale)*r->w]=cl;
      }
    }
    where += l->preAddX+l->width+l->postAddX+1;
    wmax = where>wmax?where:wmax;
    hmax = (hhere+l->preAddY+l->height+l->postAddY)>hmax?(hhere+l->preAddY+l->height+l->postAddY):hmax;
    s++;
  }

  return r;
}
