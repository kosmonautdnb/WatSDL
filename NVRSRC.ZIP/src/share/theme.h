#ifndef THEME_H
#define THEME_H

#include "BASE_C~1.H" // changed from:"base_config.h"
#include "GLEXT.H" // changed from:"glext.h"

#define THEME_IMAGES_MAX 4

struct theme
{
    GLuint tex[THEME_IMAGES_MAX];

    GLfloat t[4];
    GLfloat s[4];
};

int  theme_load(struct theme *, const char *name);
void theme_free(struct theme *);

#endif
