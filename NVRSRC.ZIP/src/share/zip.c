/* miniz.c with Neverball defaults. */
#include "ZIP.H" // changed from:"zip.h"
#include "MINIZ.C" // changed from:"miniz.c"
