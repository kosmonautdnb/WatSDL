#ifndef FS_JPG
#define FS_JPG

/*
 * jpeglib.h triggers errors due to missing size_t and FILE type
 * definitions.  Include these two headers as a workaround.
 */

#include <stddef.h> // changed from:<stddef.h>
#include <stdio.h> // changed from:<stdio.h>
extern "C" { // :mad:
#include <jpeglib.h> // changed from:<jpeglib.h>
}

#include "FS.H" // changed from:"fs.h"

void fs_jpg_src(j_decompress_ptr cinfo, fs_file infile);

#endif
