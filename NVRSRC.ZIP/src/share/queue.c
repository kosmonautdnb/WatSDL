/*
 * Copyright (C) 2009 Neverball authors
 *
 * NEVERBALL is  free software; you can redistribute  it and/or modify
 * it under the  terms of the GNU General  Public License as published
 * by the Free  Software Foundation; either version 2  of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT  ANY  WARRANTY;  without   even  the  implied  warranty  of
 * MERCHANTABILITY or  FITNESS FOR A PARTICULAR PURPOSE.   See the GNU
 * General Public License for more details.
 */

#include <stdlib.h> // changed from:<stdlib.h>
#include <assert.h> // changed from:<assert.h>
#include "QUEUE.H" // changed from:"queue.h"
#include "LIST.H" // changed from:"list.h"

struct queue
{
    List head;
    List tail;
};

Queue queue_new(void)
{
    Queue new2;

    if ((new2 = (Queue)malloc(sizeof (*new2))))
        new2->head = new2->tail = list_cons(NULL, NULL);

    return new2;
}

void queue_free(Queue q)
{
    assert(queue_empty(q));
    free(q->head);
    free(q);
}

int queue_empty(Queue q)
{
    assert(q);
    return q->head == q->tail;
}

void queue_enq(Queue q, void *data)
{
    assert(q);

    q->tail->data = data;
    q->tail->next = list_cons(NULL, NULL);

    q->tail = q->tail->next;
}

void *queue_deq(Queue q)
{
    void *data = NULL;

    if (!queue_empty(q))
    {
        data    = q->head->data;
        q->head = list_rest(q->head);
    }

    return data;
}
