#ifndef __TTF_H__
#define __TTF_H__

#include <sdl.h>
typedef int TTF_Font;

TTF_Font *TTF_OpenFontRW(void *, int, int);
void TTF_CloseFont(TTF_Font *font);
SDL_Result TTF_Init();
void TTF_Quit();
void TTF_SizeUTF8(TTF_Font *font, const char *text, int *w, int *h);
SDL_Surface *TTF_RenderUTF8_Blended(TTF_Font *font,const char *text, SDL_Color col);

#endif // __TTF_H__
