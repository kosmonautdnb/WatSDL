#ifndef ST_FAIL_H
#define ST_FAIL_H

#include <state.h> // changed from:<state.h>

extern struct state st_fail;

#endif
