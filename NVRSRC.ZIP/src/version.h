#ifndef VERSION_H
#define VERSION_H 1
#define VERSION "NeverBall WatcomGL"
#endif
