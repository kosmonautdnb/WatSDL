#ifndef ST_SET_H
#define ST_SET_H

#include "state.h" // changed from:"state.h"

extern struct state st_set;

#endif
