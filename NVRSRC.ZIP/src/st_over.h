#ifndef ST_OVER_H
#define ST_OVER_H

#include "state.h" // changed from:"state.h"

extern struct state st_over;

#endif
