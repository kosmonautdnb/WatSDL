#ifndef DEMO_SCAN
#define DEMO_SCAN

#include "DEMO.H" // changed from:"demo.h"
#include "array.h" // changed from:"array.h"
#include "dir.h" // changed from:"dir.h"

#define DEMO_GET(a, i) ((struct demo *) DIR_ITEM_GET((a), (i))->data)

Array demo_dir_scan(void);
void  demo_dir_load(Array, int lo, int hi);
void  demo_dir_free(Array);

#endif
