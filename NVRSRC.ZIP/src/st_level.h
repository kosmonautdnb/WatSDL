#ifndef ST_LEVEL_H
#define ST_LEVEL_H

#include "state.h" // changed from:"state.h"

extern struct state st_level;
extern struct state st_poser;
extern struct state st_nodemo;

int goto_exit(void);

#endif
