@echo off
echo .AL "%1" : "%2"
dir /b libs\obj\*.obj >_build\libs.lnk
_build\prepend.exe "_build\libs.lnk" "_build\libs.lnk" "FILE libs\obj\\"
wlink @_build\pmodew.lnk @%1 @_build\libs.lnk OPTION QUIET OPTION STack = 65536 NAME %2 >> R:\LOGS.LOG
rem /Axxxx means how many 4mb pages to reserve seems 256mb (64) is max (in pwmsetup.c)
rem /Vxxxx also means how many 4mb pages to reserve seems 256mb (64) is max (in pwmsetup.c)
rem /Pxxxx protected mode stack size a 16 bytes (a paragraph is 16 bytes) seems the limit is 0400 or 1024*16 so to say 16k (in pwmsetup.c)
_build\pmwsetup.exe /M0 /B0 /A64 /V64 /P1024 %2 > NUL