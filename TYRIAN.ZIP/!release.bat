call !copy.bat
call !clean.bat
call !make.bat
copy r:\main.exe tyrian.exe
del tyrian.zip
zip tyrian.zip tyrian.exe !*.* data\*.* src\*.* _build\*.* sdl2\*.*
