// Stefan Mader changed this file to get it compile with WatcomC++11 on 01 Nov 2025 (notice needed by GPL)
#ifndef VGA_PALETTE_H
#define VGA_PALETTE_H

#include "PALETTE.H" // changed from:"PALETTE.H"// changed from:"PALETTE.H"// changed from:"palette.h"

extern Palette vga_palette;

#endif // VGA_PALETTE_H
