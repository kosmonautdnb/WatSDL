/* 
 * OpenTyrian: A modern cross-platform port of Tyrian
 * Copyright (C) 2007-2009  The OpenTyrian Development Team
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
// Stefan Mader changed this file to get it compile with WatcomC++11 on 01 Nov 2025 (notice needed by GPL)
#ifndef LVLMAST_H
#define LVLMAST_H

#include "OPENTYR.H" // changed from:"opentyr.h"

#define EVENT_MAXIMUM 2500

#define WEAP_NUM    780
#define PORT_NUM    42
#define ARMOR_NUM   4
#define POWER_NUM   6
#define ENGINE_NUM  6
#define OPTION_NUM  30
#define SHIP_NUM    13
#define SHIELD_NUM  10
#define SPECIAL_NUM 46

#define ENEMY_NUM   850

extern const JE_char shapeFile[34]; /* [1..34] */

#endif /* LVLMAST_H */
