/*
 * OpenTyrian: A modern cross-platform port of Tyrian
 * Copyright (C) 2007-2009  The OpenTyrian Development Team
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
// Stefan Mader changed this file to get it compile with WatcomC++11 on 01 Nov 2025 (notice needed by GPL)
#include "JUKEBOX.H" // changed from:"jukebox.h"

#include "FONT.H" // changed from:"font.h"
#include "JOYSTICK.H" // changed from:"joystick.h"
#include "KEYBOARD.H" // changed from:"keyboard.h"
#include "LDS_PLAY.H" // changed from:"lds_play.h"
#include "LOUDNESS.H" // changed from:"loudness.h"
#include "MTRAND.H" // changed from:"mtrand.h"
#include "NORTSONG.H" // changed from:"nortsong.h"
#include "OPENTYR.H" // changed from:"opentyr.h"
#include "PALETTE.H" // changed from:"palette.h"
#include "SPRITE.H" // changed from:"sprite.h"
#include "STARLIB.H" // changed from:"starlib.h"
#include "VGA_PA~1.H" // changed from:"vga_palette.h"
#include "VIDEO.H" // changed from:"video.h"

#include <stdio.h> // changed from:<stdio.h>

void jukebox(void)  // FKA Setup.jukeboxGo
{
  bool trigger_quit = false,  // true when user wants to quit
       quitting = false;
  
  bool hide_text = false;

  bool fade_looped_songs = true, fading_song = false;
  bool stopped = false;

  bool fx = false;
  int fx_num = 0;

  int palette_fade_steps = 15;

  int diff[256][3];
  init_step_fade_palette(diff, vga_palette, 0, 255);

  JE_starlib_init();

  int fade_volume = tyrMusicVolume;
  
  for (; ; )
  {
    if (!stopped && !audio_disabled)
    {
      if (songlooped && fade_looped_songs)
        fading_song = true;

      if (fading_song)
      {
        if (fade_volume > 5)
        {
          fade_volume -= 2;
        }
        else
        {
          fade_volume = tyrMusicVolume;

          fading_song = false;
        }

        set_volume(fade_volume, fxVolume);
      }

      if (!playing || (songlooped && fade_looped_songs && !fading_song))
        play_song(mt_rand() % MUSIC_NUM);
    }

    setDelay(1);

    SDL_FillRect(VGAScreenSeg, NULL, 0);

    // starlib input needs to be rewritten
    JE_starlib_main();

    push_joysticks_as_keyboard();
    service_SDL_events(true);

    if (!hide_text)
    {
      char buffer[60];
      
      if (fx)
        snprintf_x5(buffer, sizeof(buffer), "%d %s", fx_num + 1, soundTitle[fx_num]);
      else
        snprintf_x5(buffer, sizeof(buffer), "%d %s", song_playing + 1, musicTitle[song_playing]);
      
      const int x = VGAScreen->w / 2;
      
      draw_font_hv(VGAScreen, x, 170, "Press ESC to quit the jukebox.",           small_font, centered, 1, 0);
      draw_font_hv(VGAScreen, x, 180, "Arrow keys change the song being played.", small_font, centered, 1, 0);
      draw_font_hv(VGAScreen, x, 190, buffer,                                     small_font, centered, 1, 4);
    }

    if (palette_fade_steps > 0)
      step_fade_palette(diff, palette_fade_steps--, 0, 255);
    
    JE_showVGA();

    wait_delay();

    // quit on mouse click
    Uint16 x, y;
    if (JE_mousePosition(&x, &y) > 0)
      trigger_quit = true;

    if (newkey)
    {
      switch (lastkey_scan)
      {
      case SDL_SCANCODE_ESCAPE: // quit jukebox
      case SDL_SCANCODE_Q:
        trigger_quit = true;
        break;

      case SDL_SCANCODE_SPACE:
        hide_text = !hide_text;
        break;

      case SDL_SCANCODE_F:
        fading_song = !fading_song;
        break;
      case SDL_SCANCODE_N:
        fade_looped_songs = !fade_looped_songs;
        break;

      case SDL_SCANCODE_SLASH: // switch to sfx mode
        fx = !fx;
        break;
      case SDL_SCANCODE_COMMA:
        if (fx && --fx_num < 0)
          fx_num = SOUND_COUNT - 1;
        break;
      case SDL_SCANCODE_PERIOD:
        if (fx && ++fx_num >= SOUND_COUNT)
          fx_num = 0;
        break;
      case SDL_SCANCODE_SEMICOLON:
        if (fx)
          JE_playSampleNum(fx_num + 1);
        break;

      case SDL_SCANCODE_LEFT:
      case SDL_SCANCODE_UP:
        play_song((song_playing > 0 ? song_playing : MUSIC_NUM) - 1);
        stopped = false;
        break;
      case SDL_SCANCODE_RETURN:
      case SDL_SCANCODE_RIGHT:
      case SDL_SCANCODE_DOWN:
        play_song((song_playing + 1) % MUSIC_NUM);
        stopped = false;
        break;
      case SDL_SCANCODE_S: // stop song
        stop_song();
        stopped = true;
        break;
      case SDL_SCANCODE_R: // restart song
        restart_song();
        stopped = false;
        break;

      default:
        break;
      }
    }
    
    // user wants to quit, start fade-out
    if (trigger_quit && !quitting)
    {
      palette_fade_steps = 15;
      
      SDL_Color black = { 0, 0, 0 };
      init_step_fade_solid(diff, black, 0, 255);
      
      quitting = true;
    }
    
    // if fade-out finished, we can finally quit
    if (quitting && palette_fade_steps == 0)
      break;
  }

  set_volume(tyrMusicVolume, fxVolume);
}
