// Stefan Mader changed this file to get it compile with WatcomC++11 on 01 Nov 2025 (notice needed by GPL)
#ifndef OPENTYRIAN_VERSION_H
#define OPENTYRIAN_VERSION_H

#ifndef OPENTYRIAN_VERSION
#define OPENTYRIAN_VERSION "v2.1.WatcomSDL"
#endif

#endif // OPENTYRIAN_VERSION_H
