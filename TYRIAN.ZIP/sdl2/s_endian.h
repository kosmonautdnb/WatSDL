#ifndef __S_ENDIAN_H__
#define __S_ENDIAN_H__

#include "s_std.h"

#define SDL_LITTLE_ENDIAN 0
#define SDL_BIG_ENDIAN 1
#define SDL_BYTEORDER SDL_LITTLE_ENDIAN

unsigned short SDL_SwapLE16(unsigned short a);
unsigned int SDL_SwapLE32(unsigned int a);

#endif // __S_ENDIAN_H__
