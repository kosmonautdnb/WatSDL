#ifndef __SDL_H__
#define __SDL_H__

#include "s_std.h"
#include "s_types.h"

#define SDL_VERSION_ATLEAST(__m0__, __m1__, __m2__) (1!=1)
#define SDL_MUSTLOCK(__X__) (1!=1)

#define SDL_NUM_SCANCODES 256
#define SDL_TEXTINPUTEVENT_TEXT_SIZE 256

#define SDL_TRUE 1
#define SDL_FALSE 0
#define SDL_OK 0
#define SDL_ERROR -1

#define SCANCODE_ESCAPE 1
#define SCANCODE_1 2
#define SCANCODE_2 3
#define SCANCODE_3 4
#define SCANCODE_4 5
#define SCANCODE_5 6
#define SCANCODE_6 7
#define SCANCODE_7 8
#define SCANCODE_8 9
#define SCANCODE_9 10
#define SCANCODE_0 11
#define SCANCODE_QUESTION 12
#define SCANCODE_UPPERDOT 13
#define SCANCODE_BACKSPACE 14
#define SCANCODE_TAB 15
#define SCANCODE_Q 16
#define SCANCODE_W 17
#define SCANCODE_E 18
#define SCANCODE_R 19
#define SCANCODE_T 20
#define SCANCODE_Z 21
#define SCANCODE_U 22
#define SCANCODE_I 23
#define SCANCODE_O 24
#define SCANCODE_P 25
#define SCANCODE_UE 26
#define SCANCODE_PLUS 27
#define SCANCODE_ENTER 28
#define SCANCODE_NUMENTER 28
#define SCANCODE_PAUSE 29
#define SCANCODE_CTRL 29
#define SCANCODE_A 30
#define SCANCODE_S 31
#define SCANCODE_D 32
#define SCANCODE_F 33
#define SCANCODE_G 34
#define SCANCODE_H 35
#define SCANCODE_J 36
#define SCANCODE_K 37
#define SCANCODE_L 38
#define SCANCODE_OE 39
#define SCANCODE_AE 40
#define SCANCODE_DACH 41
#define SCANCODE_LSHIFT 42
#define SCANCODE_HASHTAG 43
#define SCANCODE_Y 44
#define SCANCODE_X 45
#define SCANCODE_C 46
#define SCANCODE_V 47
#define SCANCODE_B 48
#define SCANCODE_N 49
#define SCANCODE_M 50
#define SCANCODE_COMMA 51
#define SCANCODE_DOT 52
#define SCANCODE_NUMDIVIDE 53
#define SCANCODE_MINUS 53
#define SCANCODE_RSHIFT 54
#define SCANCODE_NUMMUL 55
#define SCANCODE_PRINT 55
#define SCANCODE_ALT 56
#define SCANCODE_SPACE 57
#define SCANCODE_SHIFTLOCK 58
#define SCANCODE_F1 59
#define SCANCODE_F2 60
#define SCANCODE_F3 61
#define SCANCODE_F4 62
#define SCANCODE_F5 63
#define SCANCODE_F6 64
#define SCANCODE_F7 65
#define SCANCODE_F8 66
#define SCANCODE_F9 67
#define SCANCODE_F10 68
#define SCANCODE_NUMNUM 69
#define SCANCODE_ROLL 70
#define SCANCODE_START 71
#define SCANCODE_NUM8 72
#define SCANCODE_UP 72
#define SCANCODE_NUM7 71
#define SCANCODE_NUM9 73
#define SCANCODE_PAGEUP 73
#define SCANCODE_NUMMINUS 74
#define SCANCODE_NUM4 75
#define SCANCODE_LEFT 75
#define SCANCODE_NUM5 76
#define SCANCODE_NUM6 77
#define SCANCODE_RIGHT 77
#define SCANCODE_NUMPLUS 78
#define SCANCODE_NUM1 79
#define SCANCODE_END 79
#define SCANCODE_NUM2 80
#define SCANCODE_DOWN 80
#define SCANCODE_NUM3 81
#define SCANCODE_PAGEDOWN 81
#define SCANCODE_INSERT 82
#define SCANCODE_NUM0 82
#define SCANCODE_NUMCOMMA 83
#define SCANCODE_DELETE 83
#define SCANCODE_SMALLER 86
#define SCANCODE_F11 87
#define SCANCODE_F12 88
#define SCANCODE_WINDOWS 91

#define SCANSHIFT (0x4000)
#define SCANALT (0x8000)
#define SDL_SCANCODE_NONE 0
#define SDL_SCANCODE_UNKNOWN 0
#define SDL_SCANCODE_ESCAPE SCANCODE_ESCAPE
#define SDL_SCANCODE_SPACE SCANCODE_SPACE
#define SDL_SCANCODE_RETURN SCANCODE_ENTER
#define SDL_SCANCODE_TAB SCANCODE_TAB
#define SDL_SCANCODE_HOME SCANCODE_START
#define SDL_SCANCODE_MINUS SCANCODE_MINUS
#define SDL_SCANCODE_PLUS SCANCODE_PLUS
#define SDL_SCANCODE_END SCANCODE_END
#define SDL_SCANCODE_PAGEUP SCANCODE_PAGEUP
#define SDL_SCANCODE_PAGEDOWN SCANCODE_PAGEDOWN
#define SDL_SCANCODE_INSERT SCANCODE_INSERT
#define SDL_SCANCODE_UP SCANCODE_UP
#define SDL_SCANCODE_DOWN SCANCODE_DOWN
#define SDL_SCANCODE_LEFT SCANCODE_LEFT
#define SDL_SCANCODE_RIGHT SCANCODE_RIGHT
#define SDL_SCANCODE_F1 SCANCODE_F1
#define SDL_SCANCODE_F2 SCANCODE_F2
#define SDL_SCANCODE_F3 SCANCODE_F3
#define SDL_SCANCODE_F4 SCANCODE_F4
#define SDL_SCANCODE_F5 SCANCODE_F5
#define SDL_SCANCODE_F6 SCANCODE_F6
#define SDL_SCANCODE_F7 SCANCODE_F7
#define SDL_SCANCODE_F8 SCANCODE_F8
#define SDL_SCANCODE_F9 SCANCODE_F9
#define SDL_SCANCODE_F10 SCANCODE_F10
#define SDL_SCANCODE_F11 SCANCODE_F11
#define SDL_SCANCODE_F12 SCANCODE_F12
#define SDL_SCANCODE_0 SCANCODE_0
#define SDL_SCANCODE_1 SCANCODE_1
#define SDL_SCANCODE_2 SCANCODE_2
#define SDL_SCANCODE_3 SCANCODE_3
#define SDL_SCANCODE_4 SCANCODE_4
#define SDL_SCANCODE_5 SCANCODE_5
#define SDL_SCANCODE_6 SCANCODE_6
#define SDL_SCANCODE_7 SCANCODE_7
#define SDL_SCANCODE_8 SCANCODE_8
#define SDL_SCANCODE_9 SCANCODE_9
#define SDL_SCANCODE_KP_0 SCANCODE_NUM0
#define SDL_SCANCODE_KP_1 SCANCODE_NUM1
#define SDL_SCANCODE_KP_2 SCANCODE_NUM2
#define SDL_SCANCODE_KP_3 SCANCODE_NUM3
#define SDL_SCANCODE_KP_4 SCANCODE_NUM4
#define SDL_SCANCODE_KP_5 SCANCODE_NUM5
#define SDL_SCANCODE_KP_6 SCANCODE_NUM6
#define SDL_SCANCODE_KP_7 SCANCODE_NUM7
#define SDL_SCANCODE_KP_8 SCANCODE_NUM8
#define SDL_SCANCODE_KP_9 SCANCODE_NUM9
#define SDL_SCANCODE_KP_ENTER SCANCODE_NUMENTER
#define SDL_SCANCODE_KP_PLUS SCANCODE_NUMPLUS
#define SDL_SCANCODE_KP_MINUS SCANCODE_NUMMINUS
#define SDL_SCANCODE_NUMLOCKCLEAR SCANCODE_NUMNUM
#define SDL_SCANCODE_A SCANCODE_A
#define SDL_SCANCODE_B SCANCODE_B
#define SDL_SCANCODE_C SCANCODE_C
#define SDL_SCANCODE_D SCANCODE_D
#define SDL_SCANCODE_E SCANCODE_E
#define SDL_SCANCODE_F SCANCODE_F
#define SDL_SCANCODE_G SCANCODE_G
#define SDL_SCANCODE_H SCANCODE_H
#define SDL_SCANCODE_I SCANCODE_I
#define SDL_SCANCODE_J SCANCODE_J
#define SDL_SCANCODE_K SCANCODE_K
#define SDL_SCANCODE_L SCANCODE_L
#define SDL_SCANCODE_M SCANCODE_M
#define SDL_SCANCODE_N SCANCODE_N
#define SDL_SCANCODE_O SCANCODE_O
#define SDL_SCANCODE_P SCANCODE_P
#define SDL_SCANCODE_Q SCANCODE_Q
#define SDL_SCANCODE_R SCANCODE_R
#define SDL_SCANCODE_S SCANCODE_S
#define SDL_SCANCODE_T SCANCODE_T
#define SDL_SCANCODE_U SCANCODE_U
#define SDL_SCANCODE_V SCANCODE_V
#define SDL_SCANCODE_W SCANCODE_W
#define SDL_SCANCODE_X SCANCODE_X
#define SDL_SCANCODE_Y SCANCODE_Y
#define SDL_SCANCODE_Z SCANCODE_Z
#define SDL_SCANCODE_LCTRL SCANCODE_CTRL
#define SDL_SCANCODE_RCTRL SCANCODE_CTRL
#define SDL_SCANCODE_LALT SCANCODE_ALT
#define SDL_SCANCODE_RALT SCANCODE_ALT
#define SDL_SCANCODE_LSHIFT SCANCODE_LSHIFT
#define SDL_SCANCODE_RSHIFT SCANCODE_RSHIFT
#define SDL_SCANCODE_COMMA SCANCODE_COMMA
#define SDL_SCANCODE_SEMICOLON (SCANSHIFT|SCANCODE_COMMA)
#define SDL_SCANCODE_PERIOD (SCANSHIFT|SCANCODE_DOT)
#define SDL_SCANCODE_EQUALS (SCANSHIFT|SCANCODE_0)
#define SDL_SCANCODE_LEFTBRACKET (SCANALT|SCANCODE_8)
#define SDL_SCANCODE_RIGHTBRACKET (SCANALT|SCANCODE_9)
#define SDL_SCANCODE_CAPSLOCK SCANCODE_SHIFTLOCK
#define SDL_SCANCODE_SCROLLLOCK 0
#define SDL_SCANCODE_BACKSLASH (SCANSHIFT|SCANCODE_7)
#define SDL_SCANCODE_BACKSPACE SCANCODE_BACKSPACE
#define SDL_SCANCODE_SLASH 0
#define SDL_SCANCODE_DELETE SCANCODE_DELETE
#define SDL_SCANCODE_GRAVE SCANCODE_DOT

#define SDL_HAT_LEFT 1
#define SDL_HAT_RIGHT 2
#define SDL_HAT_UP 3
#define SDL_HAT_DOWN 4
#define SDL_HAT_CENTERED 5

#define SDL_IGNORE 6
#define SDL_RELEASED 7
#define SDL_KEYDOWN 8
#define SDL_KEYUP 9
#define KMOD_ALT 0x200
#define KMOD_SHIFT 0x400
#define KMOD_CTRL 0x800
#define KMOD_NONE 0x000
#define KMOD_GUI 0x1000

#define SDL_INIT_JOYSTICK 11

#define SDL_BUTTON_LEFT 12
#define SDL_BUTTON_MIDDLE 13
#define SDL_BUTTON_RIGHT 14

#define SDL_MOUSEBUTTONDOWN 15
#define SDL_MOUSEBUTTONUP 16

#define SDL_WINDOWEVENT 17
#define SDL_WINDOWEVENT_FOCUS_LOST 18
#define SDL_WINDOWEVENT_FOCUS_GAINED 19
#define SDL_WINDOWEVENT_RESIZED 20

#define SDL_MOUSEMOTION 21

#define SDL_TEXTINPUT 22
#define SDL_TEXTEDITING 23
#define SDL_QUIT 24

#define AUDIO_S16SYS 25
#define SDL_INIT_AUDIO 26

#define SDL_AUDIO_ALLOW_FREQUENCY_CHANGE 27

#define AUDIO_S8 28

#define SDL_INIT_VIDEO 29
#define SDL_TEXTUREACCESS_STREAMING 30


#define SDL_PIXELFORMAT_RGB888 0x10

#define SDL_WINDOW_RESIZABLE 0x01
#define SDL_WINDOW_HIDDEN 0x02
#define SDL_WINDOWPOS_CENTERED 0x04
#define SDL_WINDOW_FULLSCREEN_DESKTOP 0x08

typedef unsigned int SDL_Scancode;
typedef unsigned int SDL_Keymod;
typedef unsigned int SDL_AudioDeviceID;
typedef int SDL_Result;

typedef void(*SDL_AUDIOCALLBACK)( void *, unsigned char *, int );


typedef struct SDL_AudioCVT {
  void *buf;
  int len_mult;
  int len_cvt;
  int len;
} SDL_AudioCVT;

typedef struct SDL_AudioSpec {
  int freq;
  int format;
  int channels;
  int samples;
  SDL_AUDIOCALLBACK callback;
} SDL_AudioSpec;

typedef struct SDL_Color {
  unsigned char r,g,b,a;
} SDL_Color;

static inline SDL_Color SDL_Color_(int r,int g, int b, int a = 0xff) {SDL_Color r2; r2.r = r; r2.g=g; r2.b=b; r2.a=a; return r2;}

typedef struct SDL_Rect {
  int x, y, w, h;
} SDL_Rect;

typedef struct SDL_PixelFormat {
  int BitsPerPixel;
} SDL_PixelFormat;

typedef struct SDL_Surface {
  Uint8 *pixels;
  int w, h;
  int pitch;
  SDL_PixelFormat *format;
} SDL_Surface;

typedef struct SDL_Texture {
  unsigned int *pixels;
  unsigned int format;
  int w,h;
  int pitch;
  int flags;
} SDL_Texture;

typedef struct SDL_Window {
  int x,y,w,h;
  int flags;
} SDL_Window;

typedef struct SDL_Renderer {
  SDL_Window *window;
} SDL_Renderer;

typedef struct SDL_Joystick {
  int a;
} SDL_Joystick;

typedef struct SDL_KeySym {
  int scancode;
  int mod;
} SDL_KeySym;

typedef struct SDL_Key_Event {
  SDL_KeySym keysym;
  int state;
} SDL_Key_Event;

typedef struct SDL_Motion_Event {
  double x,y;
  double xrel,yrel;
} SDL_Motion_Event;

typedef struct SDL_Text_Event {
  char *text;
} SDL_Text_Event;

typedef struct SDL_Button_Event {
  int button;
  int x,y;
} SDL_Button_Event;

typedef struct SDL_Window_Event {
  int event;
} SDL_Window_Event;

typedef struct SDL_Event {
  int type;
  SDL_Key_Event key;
  SDL_Motion_Event motion;
  SDL_Text_Event text;
  SDL_Button_Event button;
  SDL_Window_Event window;
} SDL_Event;

SDL_Result SDL_Init(int flags);
bool SDL_WasInit(int flags);
SDL_Result SDL_InitSubSystem(int flags);
void SDL_QuitSubSystem(int flags);

int SDL_GetNumVideoDisplays();

void SDL_FillRect(SDL_Surface *surface, SDL_Rect *a, int b);

SDL_Scancode SDL_GetScancodeFromName(const char *a);
const char *SDL_GetScancodeName(SDL_Scancode a);
void SDL_Delay(double a);
void SDL_Quit();
void SDL_JoystickEventState(int state);
int SDL_JoystickGetAxis(SDL_Joystick *a, int b);
int SDL_JoystickGetButton(SDL_Joystick *a, int b);
int SDL_JoystickGetHat(SDL_Joystick *a, int b);
void SDL_JoystickUpdate();
int SDL_NumJoysticks();
SDL_Joystick *SDL_JoystickOpen(int j);
void SDL_JoystickClose(SDL_Joystick *a);
const char *SDL_JoystickName(SDL_Joystick *a);
int SDL_JoystickNumAxes(SDL_Joystick *a);
int SDL_JoystickNumButtons(SDL_Joystick *a);
int SDL_JoystickNumHats(SDL_Joystick *a);

int SDL_GetTicks();

void SDL_PushEvent(const SDL_Event *e);
bool SDL_PollEvent(SDL_Event *e);
int SDL_GetError();

void SDL_ShowCursor(const bool show);

void SDL_strlcpy(char *a, const char *b, size_t c);

void SDL_SetRelativeMouseMode(bool on);

unsigned int SDL_OpenAudioDevice(void *a, int, const SDL_AudioSpec *b, SDL_AudioSpec *c, bool d);
void SDL_PauseAudioDevice(unsigned int id, int b);
void SDL_CloseAudioDevice(unsigned int id);

void SDL_LockAudioDevice(unsigned int id);
void SDL_UnlockAudioDevice(unsigned int id);
int SDL_BuildAudioCVT(SDL_AudioCVT *cvt, unsigned int b, int c, int d, unsigned int e, int f, int g);
SDL_Result SDL_ConvertAudio(SDL_AudioCVT *cvt);

unsigned int SDL_MapRGB(SDL_PixelFormat *format, int r, int g, int b);

unsigned int SDL_GetModState();

unsigned short SDL_Swap16(unsigned short a);

SDL_Surface *SDL_CreateRGBSurface(int a, int w, int h, int cl, int d, int e, int f, int g);
SDL_Window *SDL_CreateWindow(const char *windowName,int posX, int posY, int w, int h, int flags);
SDL_Renderer *SDL_CreateRenderer(SDL_Window *a, int b, int c);
SDL_Texture *SDL_CreateTexture(SDL_Renderer *a, unsigned int format, int flags, int w, int h);
void SDL_ShowWindow(SDL_Window *a);
void SDL_SetRenderDrawColor(SDL_Renderer *z, int r, int g, int b, int a);
void SDL_RenderClear(SDL_Renderer *a);
void SDL_RenderPresent(SDL_Renderer *a);
void SDL_DestroyWindow(SDL_Window *a);
void SDL_FreeSurface(SDL_Surface *a);
void SDL_DestroyRenderer(SDL_Renderer *a);
SDL_PixelFormat *SDL_AllocFormat(unsigned int a);
const char *SDL_GetPixelFormatName(unsigned int a);
void SDL_DestroyTexture(SDL_Texture *a);
void SDL_FreeFormat(SDL_PixelFormat *a);
int SDL_GetWindowDisplayIndex(SDL_Window *a);
void SDL_GetWindowSize(SDL_Window *a, int *w, int *h);
void SDL_GetDisplayBounds(int displayIndex, SDL_Rect *b);
void SDL_SetWindowPosition(SDL_Window *a, int x, int y);
void SDL_SetWindowSize(SDL_Window *a, int w, int h);
SDL_Result SDL_SetWindowFullscreen(SDL_Window *a, bool b);

void SDL_QueryTexture(SDL_Texture *t, int *a, int *b, int *w, int *h);
void SDL_RenderCopy(SDL_Renderer *r, SDL_Texture *t, SDL_Rect *src_rect, SDL_Rect *dst_rect);

void SDL_LockTexture(SDL_Texture *t, void *a, void **data, int *pitch);
void SDL_UnlockTexture(SDL_Texture *t);


#endif // __SDL_H__
