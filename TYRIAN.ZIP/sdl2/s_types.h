#ifndef __S_TYPES_H__
#define __S_TYPES_H__

#include "s_std.h"

#endif // __S_TYPES_H__
