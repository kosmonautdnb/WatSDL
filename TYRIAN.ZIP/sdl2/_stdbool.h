#ifndef __STDBOOL_H__
#define __STDBOOL_H__

#endif // __STDBOOL_H__
