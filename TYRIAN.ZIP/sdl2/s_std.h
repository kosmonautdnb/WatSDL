#ifndef __S_STD_H__
#define __S_STD_H__

#define inline __inline
#define TARGET_WIN32
#define NDEBUG

typedef unsigned char Uint8;
typedef unsigned short Uint16;
typedef unsigned int Uint32;
typedef signed char Sint8;
typedef signed short Sint16;
typedef signed int Sint32;

#define INT8_MAX (0x7f)
#define INT8_MIN (-0x80)
#define INT16_MAX (0x7fff)
#define INT16_MIN (-0x8000)
#define INT32_MAX (0x7fffffff)
#define INT32_MIN (-0x80000000)
#define INT64_MAX (0x7fffffffffffffff)
#define INT64_MIN (-0x8000000000000000)
#define UINT8_MAX (0xff)
#define UINT8_MIN (0x00)
#define UINT16_MAX (0xffff)
#define UINT16_MIN (0x0000)
#define UINT32_MAX (0xffffffff)
#define UINT32_MIN (0x00000000)
#define UINT64_MAX (0xffffffffffffffff)
#define UINT64_MIN (0x0000000000000000)
#define SIZE_MAX UINT32_MAX

#include <direct.h>
#include <math.h>

#define floorf(__x__) (float)floor(__x__)
#define roundf(__x__) (float)round(__x__)
#define cosf(__x__) (float)cos(__x__)
#define sinf(__x__) (float)sin(__x__)
#define sqrtf(__x__) (float)sqrt(__x__)
#define fabsf(__x__) (float)fabs(__x__)
#define atanf(__x__) (float)atan(__x__)
#define atan2f(__x__,__y__) (float)atan2(__x__,__y__)
#define powf(__x__,__y__) (float)pow(__x__,__y__)

#define snprintf_x4(__a__,__b__,__c__,__d__) (sprintf(__a__,__c__,__d__) + (((char*)__a__)[(__b__)-1]=0))
#define snprintf_x5(__a__,__b__,__c__,__d__,__e__) (sprintf(__a__,__c__,__d__,__e__) + (((char*)__a__)[(__b__)-1]=0))
#define snprintf_x6(__a__,__b__,__c__,__d__,__e__,__f__) (sprintf(__a__,__c__,__d__,__e__,__f__) + (((char*)__a__)[(__b__)-1]=0))

#if defined(__WATCOMC__) && (__WATCOMC__ < 1300)
static inline double round(const double a) {return floor(a+0.5);}
#endif

static inline int mini(const int a, const int b) {return a<b?a:b;}
static inline int maxi(const int a, const int b) {return a>b?a:b;}


#endif // __S_STD_H__
