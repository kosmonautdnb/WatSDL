call !copy.bat
touch sdl2\*.*
touch src\*.*
touch *.cpp
touch *.hpp
call !clean.bat
call !make.bat
copy r:\main.exe yape_gpp.exe
del yape.zip
zip yape.zip yape.exe yape_gpp.exe !*.* src\*.* _build\*.* sdl2\*.* *.cpp *.hpp *.d64
