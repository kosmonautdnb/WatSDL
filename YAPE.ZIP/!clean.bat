call _BUILD\MAKEMK.BAT
call wmake.exe /f R:\MAKEFILE clean