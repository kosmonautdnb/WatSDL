wpp386 /mf sdl.cpp
del sdl.obj
