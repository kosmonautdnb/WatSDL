#pragma once

#include "MEM.H" // changed from:"mem.h"
#include "CPU.H" // changed from:"cpu.h"

template <class T>
class StaticList
{
public:
    StaticList(unsigned int dev, T* instance) {
    if (!refCount) {
      for(unsigned int i = 0; i < 16; i++) {
        itemHeap[i] = item[i] = 0;
      }
    }
    if (dev < 16) {
            item[dev] = instance;
        }
        slotNr = dev;
    itemHeap[refCount] = instance;
    refCount++;
    }
    virtual ~StaticList() {
        item[slotNr] = NULL;
    refCount--;
    itemHeap[refCount] = NULL;
    }
  static T *itemHeap[16];
protected:
  static unsigned int refCount;
    static T *item[16];
    unsigned int slotNr;

  friend class TED;
};

template <class T> unsigned int StaticList<T>::refCount = 0;
template <class T> T *StaticList<T>::item[16];
template <class T> T *StaticList<T>::itemHeap[16];

class DRVMEM;
class CPU;
class Mem;
class Cpu;

#pragma warning(push)
#pragma warning(disable: 4355)
class Clockable : public StaticList<Clockable>
{
public:
  Clockable(unsigned int dn) : StaticList<Clockable>(dn, this), devNr_(dn) {
  }
  virtual ~Clockable() {}
  // Clock the drive (1 cycle)
  //virtual
    void Clock();
  // Clock the drive (n cycles)
  //virtual
    void Clock(unsigned int n);
  inline unsigned int getDevNr() {
    return devNr_;
  }
  inline unsigned int getClockRate() {
    return ClockRate;
  }
  inline unsigned long getClockCount() {
    return ClockCount;
  }
  DRVMEM *getDriveMemHandler() {
    return static_cast<DRVMEM*>(Mem);
  };
  // Obtain pointer to the CPU object
  CPU *getDriveCpu() {
    return static_cast<CPU*>(Cpu);
  };
  unsigned long ClockRate;
  unsigned long ClockCount;

protected:
  CPU *Cpu;
  DRVMEM *Mem;
  unsigned int devNr_;
};
#pragma warning(pop)

inline void Clockable::Clock(unsigned int n)
{
  do {
    Mem->EmulateTick();
    Cpu->process();
  } while (--n);
}

inline void Clockable::Clock()
{
  Mem->EmulateTick();
  Cpu->process();
}
