_build\text.exe
@echo off
@echo Starting.. (needs RamDisk at R:)
rem @echo system dos4g > R:\LINK.LNK
@echo system pmodew > R:\LINK.LNK
@echo -oR:\main.exe > R:\LINK2.LNK
@echo build errors > R:\LOGS.LOG
_BUILD\FLTMECHK.exe !MAK R:\gltest.exe
if not ERRORLEVEL 255 call _BUILD\MAKEMK.BAT
SET DJGPPCOMPILE=1
call wmake.exe /f R:\makefile /e /s /k
if %DJGPPCOMPILE%==0 m R:\logs.log
