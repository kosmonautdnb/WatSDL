copy /Y c:\_STL_\types.hpp
copy /Y c:\_STL_\array.hpp
copy /Y c:\_STL_\object.hpp
copy /Y c:\_STL_\object.cpp
copy /Y c:\_STL_\string.hpp
copy /Y c:\_STL_\string.cpp
copy /Y c:\_OPENGL_\GLIMPL.CPP c:\SDL\SDL2
copy /Y c:\_OPENGL_\GL.H c:\SDL\SDL2
deltree /Y SDL2
mkdir SDL2
copy /Y c:\SDL\SDL2\*.* SDL2
copy /Y c:\_VCODE_\VCODE.EXE
