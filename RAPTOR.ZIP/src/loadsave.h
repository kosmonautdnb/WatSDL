// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once

#include "RAP.H" // changed from:"rap.h"

typedef struct 
{
    int link;
    int slib;
    int x;
    int y;
    int game;
    int level;
}CSPRITE;

typedef struct 
{
    short flats;
    short fgame;
}MAZEDATA;

typedef struct 
{
    int sizerec;
    int spriteoff;
    int numsprites;
    MAZEDATA map[MAP_SIZE];
}MAZELEVEL;

extern int curplr_diff;

extern MAZELEVEL *mapmem;
extern CSPRITE *csprite;

const char* RAP_InitLoadSave(void);
const char* RAP_SetupFilename(void);
void RAP_WriteDefaultSetup(void);
const char* RAP_GetPath(void);
int RAP_CheckFileInPath(const char* filename);

void RAP_ClearPlayer(void);
int RAP_IsSaveFile(PLAYEROBJ *in_plr);
int RAP_FFSaveFile(void);
void RAP_SetPlayerDiff(void);
int RAP_SavePlayer(void);
