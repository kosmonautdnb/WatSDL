#pragma once

void FLAME_Init(void);
void FLAME_InitShades(void);
void FLAME_Up(int ix, int iy, int width, int frame);
void FLAME_Down(int ix, int iy, int width, int frame);