// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once

void FLAME_Init(void);
void FLAME_InitShades(void);
void FLAME_Up(int ix, int iy, int width, int frame);
void FLAME_Down(int ix, int iy, int width, int frame);