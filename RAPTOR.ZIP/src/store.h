#pragma once

extern int id_pics[4];

void STORE_Enter(void);
