// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once

extern int id_pics[4];

void STORE_Enter(void);
