// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once
int IMS_IsAck(void);
void IMS_StartAck(void);
int IMS_CheckAck(void);
int IMS_WaitTimed(int secs);
