#pragma once
int IMS_IsAck(void);
void IMS_StartAck(void);
int IMS_CheckAck(void);
int IMS_WaitTimed(int secs);
