// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once

int INTRO_Credits(void);
int INTRO_PlayMain(void);
int INTRO_Landing(void);
int INTRO_Death(void);
void INTRO_EndGame(int game);
