#pragma once

int INTRO_Credits(void);
int INTRO_PlayMain(void);
int INTRO_Landing(void);
int INTRO_Death(void);
void INTRO_EndGame(int game);
