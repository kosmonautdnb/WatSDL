// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once
#include "RAP.H" // changed from:"rap.h"

typedef enum
{
    E_FORWARD,
    E_BACKWARD
}EDIR;

typedef enum
{
    KAMI_FLY,
    KAMI_CHASE,
    KAMI_END
}KAMI;

typedef enum
{
    GANIM_DONE,
    GANIM_OFF,
    GANIM_ON
}GANIM;

typedef enum
{
    MULTI_OFF,
    MULTI_START,
    MULTI_END
}MULTI;

typedef struct 
{
    char iname[16];                         // ITEM NAME
    int item;                               // * GLB ITEM #
    int bonus;                              // BONUS # ( -1 == NONE )
    int exptype;                            // EXPLOSION TYPE 
    int shootspace;                         // SLOWDOWN SPEED
    int ground;                     //NOT USED IS ON GROUND
    int suck;                               // CAN SUCK WEAPON AFFECT
    int frame_rate;                         // FRAME RATE
    int num_frames;                         // NUM FRAMES
    int countdown;                          // COUNT DOWN TO START ANIM
    int rewind;                             // FRAMES TO REWIND
    int animtype;                           // FREE SPACE FOR LATER USE
    int shadow;                             // USE SHADOW ( TRUE/FALSE )
    int bossflag;                           // SHOULD THIS BE CONSIDERED A BOSS
    int hits;                               // HIT POINTS
    int money;                              // $$ AMOUNT WHEN KILLED
    int shootstart;                         // SHOOT START OFFSET
    int shootcnt;                           // HOW MANY TO SHOOT
    int shootframe;                         // FRAME RATE TO SHOOT
    int movespeed;                          // MOVEMENT SPEED
    int numflight;                          // NUMBER OF FLIGHT POSITIONS
    int repos;                              // REPEAT TO POSITION
    int flighttype;                         // FLIGHT TYPE
    int numguns;                            // NUMBER OF GUNS
    int numengs;                            // NUMBER OF ENGINES
    int sfx;                        //NOT USED SFX # TO PLAY
    int song;                               // SONG # TO PLAY
    short shoot_type[MAX_GUNS];             // ENEMY SHOOT TYPE
    short engx[MAX_GUNS];                   // X POS ENGINE FLAME
    short engy[MAX_GUNS];                   // Y POS ENGINE FLAME
    short englx[MAX_GUNS];                  // WIDTH OF ENGINE FLAME
    short shootx[MAX_GUNS];                 // X POS SHOOT FROM
    short shooty[MAX_GUNS];                 // Y POS SHOOT FROM
    short flightx[MAX_FLIGHT];              // FLIGHT X POS
    short flighty[MAX_FLIGHT];              // FLIGHT Y POS
}SPRITE;

typedef struct SPRITE_SHIP_S 
{
    struct SPRITE_SHIP_S *prev;
    struct SPRITE_SHIP_S *next;
    int item;                         // GLB item of current frame
    SPRITE *lib;                      // SPRITE LIB POS
    int sx;                           // START X
    int sy;                           // START Y
    int x;                            // CENTER X POS;
    int y;                            // Y POS
    int x2;                           // WIDTH
    int y2;                           // HEIGHT           
    int width;                        // WIDTH
    int height;                       // HEIGHT
    int hlx;                          // WIDTH/2
    int hly;                          // HEIGHT/2
    int movepos;                      // CUR POSITION IN FLIGHT (X/Y)
    int shootagain;                   // * COUNT DOWN TO SHOOT
    int shootcount;                   // * COUNT TO SHOOT
    int shootflag;                    // * COUNTER TO SPACE SHOTS
    int hits;                         // *
    int groundflag;                   // *
    int doneflag;
    MOVEOBJ move;
    int countdown;
    int curframe;
    int eframe;
    int num_frames;
    int anim_on;
    int edir;
    int kami;
    int frame_rate;
    int shoot_on;
    int shoot_disable;
    int multi;
    int speed;
    int suckagain;
}SPRITE_SHIP;

#define E_NUM_DIFF    4

#define E_SECRET_1    0
#define E_SECRET_2    1
#define E_SECRET_3    2
#define E_EASY_LEVEL  3
#define E_MED_LEVEL   4
#define E_HARD_LEVEL  5
#define E_TRAIN_LEVEL 6

#define EB_SECRET_1    1
#define EB_SECRET_2    2
#define EB_SECRET_3    4
#define EB_EASY_LEVEL  8
#define EB_MED_LEVEL   16
#define EB_HARD_LEVEL  32
#define EB_NOT_USED    64

extern SPRITE_SHIP first_enemy, last_enemy;
void ENEMY_Clear(void);
void ENEMY_LoadLib(void);
void ENEMY_LoadSprites(void);
void ENEMY_FreeSprites(void);
SPRITE_SHIP *ENEMY_GetRandom(void);
SPRITE_SHIP *ENEMY_GetRandomAir(void);
SPRITE_SHIP *ENEMY_DamageEnergy(int x, int y, int damage);
int ENEMY_DamageAll(int x, int y, int damage);
int ENEMY_DamageGround(int x, int y, int damage);
int ENEMY_DamageAir(int x, int y, int damage);
int ENEMY_GetBaseDamage(void);
void ENEMY_Think(void);
void ENEMY_DisplayGround(void);
void ENEMY_DisplaySky(void);
