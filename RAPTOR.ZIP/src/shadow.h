// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once

extern int num_gshadows;
extern int num_shadows;

void SHADOW_Init(void);
void SHADOW_MakeShades(void);
void SHADOW_GAdd(int item, int x, int y);
void SHADOW_Add(int item, int x, int y);
void SHADOW_DisplayGround();
void SHADOW_DisplaySky();
