#pragma once

void HELP_Init(void);
void HELP_Win(const char *strpage);
