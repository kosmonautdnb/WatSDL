// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once

void HELP_Init(void);
void HELP_Win(const char *strpage);
