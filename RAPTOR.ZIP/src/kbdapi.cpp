// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#include <string.h> // changed from:<string.h>
#include <ctype.h> // changed from:<ctype.h>
#include "SDL.h" // changed from:"SDL.h"
#include "COMMON.H" // changed from:"common.h"
#include "KBDAPI.H" // changed from:"kbdapi.h"
#include "I_VIDEO.H" // changed from:"i_video.h"

int kbd_ack;
int capslock;
int lastscan, lastascii;
int keyboard[256];
void (*kbdhook)(void);

int ASCIINames[] = {
    0x00, 0x1B, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x30, 0x2D, 0x3D, 0x08, 0x09,
    0x71, 0x77, 0x65, 0x72, 0x74, 0x79, 0x75, 0x69, 0x6F, 0x70, 0x5B, 0x5D, 0x0D, 0x00, 0x61, 0x73,
    0x64, 0x66, 0x67, 0x68, 0x6A, 0x6B, 0x6C, 0x3B, 0x27, 0x60, 0x00, 0x5C, 0x7A, 0x78, 0x63, 0x76,
    0x62, 0x6E, 0x6D, 0x2C, 0x2E, 0x2F, 0x00, 0x2A, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x37, 0x38, 0x39, 0x2D, 0x34, 0x35, 0x36, 0x2B, 0x31,
    0x32, 0x33, 0x30, 0x7F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x1B, 0x21, 0x40, 0x23, 0x24, 0x25, 0x5E, 0x26, 0x2A, 0x28, 0x29, 0x5F, 0x2B, 0x08, 0x09,
    0x51, 0x57, 0x45, 0x52, 0x54, 0x59, 0x55, 0x49, 0x4F, 0x50, 0x7B, 0x7D, 0x0D, 0x00, 0x41, 0x53,
    0x44, 0x46, 0x47, 0x48, 0x4A, 0x4B, 0x4C, 0x3A, 0x22, 0x7E, 0x00, 0x7C, 0x5A, 0x58, 0x43, 0x56,
    0x42, 0x4E, 0x4D, 0x3C, 0x3E, 0x3F, 0x00, 0x2A, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x37, 0x38, 0x39, 0x2D, 0x34, 0x35, 0x36, 0x2B, 0x31,
    0x32, 0x33, 0x30, 0x7F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};

int ScanCodeMap[] = {
    0,
    0,
    0,
    0,
    0x1e,
    0x30,
    0x2e,
    0x20,
    0x12,
    0x21,

    0x22,
    0x23,
    0x17,
    0x24,
    0x25,
    0x26,
    0x32,
    0x31,
    0x18,
    0x19,

    0x10,
    0x13,
    0x1f,
    0x14,
    0x16,
    0x2f,
    0x11,
    0x2d,
    0x15,
    0x2c,

    0x02,
    0x03,
    0x04,
    0x05,
    0x06,
    0x07,
    0x08,
    0x09,
    0x0a,
    0x0b,

    0x1c,
    0x01,
    0x0e,
    0x0f,
    0x39,
    0x0c,
    0x0d,
    0x1a,
    0x1b,
    0x2b,

    0,
    0x27,
    0x28,
    0x29,
    0x33,
    0x34,
    0x35,
    0x3a,
    0x3b,
    0x3c,

    0x3d,
    0x3e,
    0x3f,
    0x40,
    0x41,
    0x42,
    0x43,
    0x44,
    0x56,
    0x58,

    0xe0,
    0x46,
    0xe0,
    0x52,
    0x47,
    0x49,
    0x53,
    0x4f,
    0x51,
    0x4d,

    0x4b,
    0x50,
    0x48,
    0x45,
    0xe0,
    0x37,
    0x4a,
    0x4e,
    0x1c,
    0x4f,

    0x50,
    0x51,
    0x4b,
    0x4c,
    0x4d,
    0x47,
    0x48,
    0x49,
    0x52,
    0x53,
};

#define CONVKBDR(__key__,__scancode__) case (__scancode__):{key=(__key__);}break;
#define CONVKBDA CONVKBDR(SC_NONE,SDL_SCANCODE_NONE)\
CONVKBDR(SC_BAD,255)\
CONVKBDR(SC_ESC,SDL_SCANCODE_ESCAPE)\
CONVKBDR(SC_F1,SDL_SCANCODE_F1)\
CONVKBDR(SC_F2,SDL_SCANCODE_F2)\
CONVKBDR(SC_F3,SDL_SCANCODE_F3)\
CONVKBDR(SC_F4,SDL_SCANCODE_F4)\
CONVKBDR(SC_F5,SDL_SCANCODE_F5)\
CONVKBDR(SC_F6,SDL_SCANCODE_F6)\
CONVKBDR(SC_F7,SDL_SCANCODE_F7)\
CONVKBDR(SC_F8,SDL_SCANCODE_F8)\
CONVKBDR(SC_F9,SDL_SCANCODE_F9)\
CONVKBDR(SC_F10,SDL_SCANCODE_F10)\
CONVKBDR(SC_F11,SDL_SCANCODE_F11)\
CONVKBDR(SC_F12,SDL_SCANCODE_F12)\
CONVKBDR(SC_TAB,SDL_SCANCODE_TAB)\
CONVKBDR(SC_SLASH,245)\
CONVKBDR(SC_CAPS_LOCK,248)\
CONVKBDR(SC_LEFT_SHIFT,SDL_SCANCODE_LSHIFT)\
CONVKBDR(SC_CTRL,SDL_SCANCODE_LCTRL)\
CONVKBDR(SC_ALT,SDL_SCANCODE_LALT)\
CONVKBDR(SC_SCROLL_LOCK,247)\
CONVKBDR(SC_BACKSPACE,SDL_SCANCODE_BACKSPACE)\
CONVKBDR(SC_ENTER,SDL_SCANCODE_RETURN)\
CONVKBDR(SC_RIGHT_SHIFT,SDL_SCANCODE_RSHIFT)\
CONVKBDR(SC_RIGHT_ALT,244)\
CONVKBDR(SC_RIGHT_CTRL,243)\
CONVKBDR(SC_EXT_INSERT,242)\
CONVKBDR(SC_EXT_DELETE,241)\
CONVKBDR(SC_EXT_HOME,240)\
CONVKBDR(SC_EXT_END,239)\
CONVKBDR(SC_EXT_PAGEUP,238)\
CONVKBDR(SC_EXT_PAGEDN,237)\
CONVKBDR(SC_EXT_UP,236)\
CONVKBDR(SC_EXT_DN,235)\
CONVKBDR(SC_EXT_LEFT,234)\
CONVKBDR(SC_EXT_RIGHT,233)\
CONVKBDR(SC_EXT_ENTER,232)\
CONVKBDR(SC_NUMLOCK,231)\
CONVKBDR(SC_INSERT,SDL_SCANCODE_INSERT)\
CONVKBDR(SC_DELETE,SDL_SCANCODE_DELETE)\
CONVKBDR(SC_HOME,SDL_SCANCODE_HOME)\
CONVKBDR(SC_END,SDL_SCANCODE_END)\
CONVKBDR(SC_PAGEUP,SDL_SCANCODE_PAGEUP)\
CONVKBDR(SC_PAGEDN,SDL_SCANCODE_PAGEDOWN)\
CONVKBDR(SC_UP,SDL_SCANCODE_UP)\
CONVKBDR(SC_DOWN,SDL_SCANCODE_DOWN)\
CONVKBDR(SC_LEFT,SDL_SCANCODE_LEFT)\
CONVKBDR(SC_RIGHT,SDL_SCANCODE_RIGHT)\
CONVKBDR(SC_1,SDL_SCANCODE_1)\
CONVKBDR(SC_2,SDL_SCANCODE_2)\
CONVKBDR(SC_3,SDL_SCANCODE_3)\
CONVKBDR(SC_4,SDL_SCANCODE_4)\
CONVKBDR(SC_5,SDL_SCANCODE_5)\
CONVKBDR(SC_6,SDL_SCANCODE_6)\
CONVKBDR(SC_7,SDL_SCANCODE_7)\
CONVKBDR(SC_8,SDL_SCANCODE_8)\
CONVKBDR(SC_9,SDL_SCANCODE_9)\
CONVKBDR(SC_0,SDL_SCANCODE_0)\
CONVKBDR(SC_Q,SDL_SCANCODE_Q)\
CONVKBDR(SC_W,SDL_SCANCODE_W)\
CONVKBDR(SC_E,SDL_SCANCODE_E)\
CONVKBDR(SC_R,SDL_SCANCODE_R)\
CONVKBDR(SC_T,SDL_SCANCODE_T)\
CONVKBDR(SC_Y,SDL_SCANCODE_Y)\
CONVKBDR(SC_U,SDL_SCANCODE_U)\
CONVKBDR(SC_I,SDL_SCANCODE_I)\
CONVKBDR(SC_O,SDL_SCANCODE_O)\
CONVKBDR(SC_P,SDL_SCANCODE_P)\
CONVKBDR(SC_A,SDL_SCANCODE_A)\
CONVKBDR(SC_S,SDL_SCANCODE_S)\
CONVKBDR(SC_D,SDL_SCANCODE_D)\
CONVKBDR(SC_F,SDL_SCANCODE_F)\
CONVKBDR(SC_G,SDL_SCANCODE_G)\
CONVKBDR(SC_H,SDL_SCANCODE_H)\
CONVKBDR(SC_J,SDL_SCANCODE_J)\
CONVKBDR(SC_K,SDL_SCANCODE_K)\
CONVKBDR(SC_L,SDL_SCANCODE_L)\
CONVKBDR(SC_Z,SDL_SCANCODE_Z)\
CONVKBDR(SC_X,SDL_SCANCODE_X)\
CONVKBDR(SC_C,SDL_SCANCODE_C)\
CONVKBDR(SC_V,SDL_SCANCODE_V)\
CONVKBDR(SC_B,SDL_SCANCODE_B)\
CONVKBDR(SC_N,SDL_SCANCODE_N)\
CONVKBDR(SC_M,SDL_SCANCODE_M)\
CONVKBDR(SC_SPACE,SDL_SCANCODE_SPACE)\
CONVKBDR(SC_RELEASE,249)\
CONVKBDR(SC_MINUS,SDL_SCANCODE_MINUS)

/***************************************************************************
I_HandleKeyboardEvent() - Get current key status
 ***************************************************************************/
void 
I_HandleKeyboardEvent(
    SDL_Event *sdlevent
)
{
    int key = 0;
    
    if (sdlevent->type != SDL_KEYDOWN && sdlevent->type != SDL_KEYUP)
        return;
    
    switch (sdlevent->key.keysym.scancode)
    {
    case SDL_SCANCODE_LCTRL:
    //case SDL_SCANCODE_RCTRL:
        key = 0x1d;
        break;
    
    case SDL_SCANCODE_LSHIFT:
        key = 0x2a;
        break;
    
    case SDL_SCANCODE_RSHIFT:
        key = 0x36;
        break;
    
    case SDL_SCANCODE_LALT:
    //case SDL_SCANCODE_RALT:
        key = 0x38;
        break;

#ifdef __ANDROID__
    case SDL_SCANCODE_AC_BACK:
        key = 0x01;
        break;
#endif //__ANDROID__

    default:
        if (sdlevent->key.keysym.scancode >= 0 && sdlevent->key.keysym.scancode < 100) {
            key = ScanCodeMap[sdlevent->key.keysym.scancode];
        }
        break;
    }
    
    if (!key)
        return;

    if (sdlevent->type == SDL_KEYUP)
    {
        kbd_ack = 0;
        keyboard[key] = 0;
        if (key == SC_CAPS_LOCK)
            capslock = 0;
    }
    else
    {
        kbd_ack = 1;
        lastscan = key;
        keyboard[key] = 1;
        if (key && KBD_ISCAPS != 0)
            lastascii = ASCIINames[128 + key];
        else
            lastascii = ASCIINames[key];
        if (key == SC_CAPS_LOCK)
            capslock = 1;
    }
}

/***************************************************************************
   KBD_Clear() - Resets all flags
 ***************************************************************************/
void 
KBD_Clear(
    void
)
{
    lastscan = SC_NONE;
    memset(keyboard, 0, sizeof(keyboard));
}

/***************************************************************************
 KBD_SetKeyboardHook() - Sets User function to call from keyboard handler
 ***************************************************************************/
void                       // RETURN: none
KBD_SetKeyboardHook(
    void (*hook)(void)     // INPUT : pointer to function
)
{
    kbdhook = hook;
}

/***************************************************************************
   KBD_Ascii2Scan () - converts most ASCII chars to keyboard scan code
 ***************************************************************************/
int                       // RETURN: scan code
KBD_Ascii2Scan(
    int ascii             // INPUT : ASCII character
)
{
    int loop;
    
    ascii = tolower(ascii);
    
    for (loop = 0; loop < 100; loop++)
    {
        if (ASCIINames[loop] == ascii)
            return loop;
    }
    
    return 0;
}

/***************************************************************************
KBD_Wait() - Waits for Key to be released
 ***************************************************************************/
void 
KBD_Wait(
    int scancode           // SCANCODE see kbdapi.h
)
{
    while (KBD_Key(scancode))
    {
        I_GetEvent();
    }
    
    lastscan = SC_NONE;
    lastascii = SC_NONE;
}

/***************************************************************************
KBD_IsKey() - Tests to see if key is down if so waits for release
 ***************************************************************************/
int 
KBD_IsKey(
    int scancode          // SCANCODE see kbdapi.h
)
{
    if (KBD_Key(scancode))
    {
        KBD_Wait(scancode);
        return 1;
    }
    
    return 0;
}

/***************************************************************************
   KBD_Install() - Sets up keyboard system
 ***************************************************************************/
void 
KBD_Install(
    void
)
{
    memset(keyboard, 0, sizeof(keyboard));
}

/***************************************************************************
   KBD_End() - Shuts down KBD system
 ***************************************************************************/
void 
KBD_End(
    void
)
{

}

