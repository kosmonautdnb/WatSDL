// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once
//#include "SDL_endian.h" // changed from:"SDL_endian.h"
#include <SDL.H> //:mad:

#define LE_USHORT(x) SDL_SwapLE16(x)
#define LE_SHORT(x) (signed short) SDL_SwapLE16(x)
#define LE_ULONG(x) SDL_SwapLE32(x)
#define LE_LONG(x) (signed int) SDL_SwapLE32(x)