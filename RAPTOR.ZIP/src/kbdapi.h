// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once

#include <sdl.h> // :mad:

// SCAN CODES

#define SC_NONE  0x0000
#define SC_BAD 0x00ff
#define SC_ESC 0x0001
#define SC_F1 0x003b
#define SC_F2 0x003c
#define SC_F3 0x003d
#define SC_F4 0x003e
#define SC_F5 0x003f
#define SC_F6 0x0040
#define SC_F7 0x0041
#define SC_F8 0x0042
#define SC_F9 0x0043
#define SC_F10 0x0044
#define SC_F11 0x0057
#define SC_F12 0x0058
#define SC_TAB 0x000f
#define SC_SLASH 0x002b
#define SC_CAPS_LOCK 0x003a
#define SC_LEFT_SHIFT 0x002a
#define SC_CTRL 0x001d
#define SC_ALT 0x0038
#define SC_SCROLL_LOCK 0x0046
#define SC_BACKSPACE 0x000e
#define SC_ENTER 0x001c
#define SC_RIGHT_SHIFT 0x0036
#define SC_RIGHT_ALT 0xe038
#define SC_RIGHT_CTRL 0xe010
#define SC_EXT_INSERT 0xe052
#define SC_EXT_DELETE 0xe053
#define SC_EXT_HOME 0xe047
#define SC_EXT_END 0xe04f
#define SC_EXT_PAGEUP 0xe049
#define SC_EXT_PAGEDN 0xe051
#define SC_EXT_UP 0xe048
#define SC_EXT_DN 0xe050
#define SC_EXT_LEFT 0xe04b
#define SC_EXT_RIGHT 0xe04d
#define SC_EXT_ENTER 0xe01c
#define SC_NUMLOCK 0x0045
#define SC_INSERT 0x0052
#define SC_DELETE 0x0053
#define SC_HOME 0x0047
#define SC_END 0x004f
#define SC_PAGEUP 0x0049
#define SC_PAGEDN 0x0051
#define SC_UP 0x0048
#define SC_DOWN 0x0050
#define SC_LEFT  0x004b
#define SC_RIGHT 0x004d
#define SC_1 0x0002
#define SC_2 0x0003
#define SC_3 0x0004
#define SC_4 0x0005
#define SC_5 0x0006
#define SC_6 0x0007
#define SC_7 0x0008
#define SC_8 0x0009
#define SC_9 0x000a
#define SC_0 0x000b
#define SC_Q 0x0010
#define SC_W 0x0011
#define SC_E 0x0012
#define SC_R 0x0013
#define SC_T 0x0014
#define SC_Y 0x0015
#define SC_U 0x0016
#define SC_I 0x0017
#define SC_O 0x0018
#define SC_P 0x0019
#define SC_A 0x001e
#define SC_S 0x001f
#define SC_D 0x0020
#define SC_F 0x0021
#define SC_G 0x0022
#define SC_H 0x0023
#define SC_J 0x0024
#define SC_K 0x0025
#define SC_L 0x0026
#define SC_Z 0x002c
#define SC_X 0x002d
#define SC_C 0x002e
#define SC_V 0x002f
#define SC_B 0x0030
#define SC_N 0x0031
#define SC_M 0x0032
#define SC_SPACE 0x0039
#define SC_RELEASE 0x0080
#define SC_MINUS 12

extern int keyboard[256];
extern int lastscan;
extern int lastascii;
extern int kbd_ack;
extern int capslock;

#define KBD_Key(c) keyboard[c]
#define KBD_ISCAPS (capslock+keyboard[SC_LEFT_SHIFT]+keyboard[SC_RIGHT_SHIFT])
#define KBD_LASTSCAN  lastscan
#define KBD_LASTASCII lastascii

void KBD_Clear(void);
void KBD_Install(void);
void KBD_End(void);
int KBD_IsKey(int scancode);
void KBD_Wait(int scancode);
