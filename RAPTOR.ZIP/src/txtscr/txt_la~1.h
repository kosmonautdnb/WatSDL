//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#ifndef TXT_LABEL_H
#define TXT_LABEL_H

/**
 * @file txt_label.h
 *
 * Text label widget.
 */

/**
 * Label widget.
 *
 * A label widget does nothing except show a text label.
 */

typedef struct txt_label_s txt_label_t;

#include "TXT_MAIN.H" // changed from:"txt_main.h"
#include "TXT_WI~1.H" // changed from:"txt_widget.h"

struct txt_label_s
{
    txt_widget_t widget;
    char *label;
    char **lines;
    unsigned int w, h;
    int fgcolor;
    int bgcolor;
    int customlabel;
};

/**
 * Create a new label widget.
 *
 * @param label         String to display in the widget (UTF-8 format).
 * @return              Pointer to the new label widget.
 */

txt_label_t *TXT_NewLabel(const char *label);

/**
 * Create a new label widget at position +1 on x axis.
 *
 * @param label         String to display in the widget (UTF-8 format).
 * @return              Pointer to the new label widget.
 */

txt_label_t* TXT_NewSpecialLabel(const char* label);

/**
 * Set the string displayed in a label widget.
 *
 * @param label         The widget.
 * @param value         The string to display (UTF-8 format).
 */

void TXT_SetLabel(txt_label_t *label, const char *value);

/**
 * Set the background color of a label widget.
 *
 * @param label         The widget.
 * @param color         The background color to use.
 */

void TXT_SetBGColor(txt_label_t *label, txt_color_t color);

/**
 * Set the foreground color of a label widget.
 *
 * @param label         The widget.
 * @param color         The foreground color to use.
 */

void TXT_SetFGColor(txt_label_t *label, txt_color_t color);

#endif /* #ifndef TXT_LABEL_H */


