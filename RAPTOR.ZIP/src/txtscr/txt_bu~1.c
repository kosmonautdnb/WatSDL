//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#include <stdlib.h> // changed from:<stdlib.h>
#include <string.h> // changed from:<string.h>

#include "DOOMKEYS.H" // changed from:"doomkeys.h"

#include "TXT_BU~1.H" // changed from:"txt_button.h"
#include "TXT_GUI.H" // changed from:"txt_gui.h"
#include "TXT_IO.H" // changed from:"txt_io.h"
#include "TXT_MAIN.H" // changed from:"txt_main.h"
#include "TXT_UTF8.H" // changed from:"txt_utf8.h"
#include "TXT_WI~2.H" // changed from:"txt_window.h"

#ifdef _MSC_VER
#define strdup _strdup
#endif

static void TXT_ButtonSizeCalc(TXT_UNCAST_ARG(button))
{
    TXT_CAST_ARG(txt_button_t, button);

    button->widget.w = TXT_UTF8_Strlen(button->label);
    button->widget.h = 1;
}

static void TXT_ButtonDrawer(TXT_UNCAST_ARG(button))
{
    TXT_CAST_ARG(txt_button_t, button);
    int i;
    int w;

    w = button->widget.w;

    TXT_SetWidgetBG(button);

    TXT_DrawString(button->label);

    for (i = TXT_UTF8_Strlen(button->label); i < w; ++i)
    {
        TXT_DrawString(" ");
    }
}

static void TXT_ButtonDestructor(TXT_UNCAST_ARG(button))
{
    TXT_CAST_ARG(txt_button_t, button);

    free(button->label);
}

static int TXT_ButtonKeyPress(TXT_UNCAST_ARG(button), int key)
{
    TXT_CAST_ARG(txt_button_t, button);

    if (key == KEY_ENTER)
    {
        TXT_EmitSignal(button, "pressed");
        return 1;
    }

    return 0;
}

static void TXT_ButtonMousePress(TXT_UNCAST_ARG(button), int x, int y, int b)
{
    TXT_CAST_ARG(txt_button_t, button);

    if (b == TXT_MOUSE_LEFT)
    {
        // Equivalent to pressing enter

        TXT_ButtonKeyPress(button, KEY_ENTER);
    }
}

txt_widget_class_t txt_button_class =
{
    TXT_AlwaysSelectable,
    TXT_ButtonSizeCalc,
    TXT_ButtonDrawer,
    TXT_ButtonKeyPress,
    TXT_ButtonDestructor,
    TXT_ButtonMousePress,
    NULL,
};

void TXT_SetButtonLabel(txt_button_t *button, const char *label)
{
    free(button->label);
    button->label = strdup(label);
}

txt_button_t *TXT_NewButton(const char *label)
{
    txt_button_t *button;

    button = (txt_button_t *)malloc(sizeof(txt_button_t));

    TXT_InitWidget(button, &txt_button_class);
    button->label = strdup(label);

    return button;
}

// Button with a callback set automatically

txt_button_t *TXT_NewButton2(const char *label, TxtWidgetSignalFunc func,
                             void *user_data)
{
    txt_button_t *button;

    button = TXT_NewButton(label);

    TXT_SignalConnect(button, "pressed", func, user_data);

    return button;
}

