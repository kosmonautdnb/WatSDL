//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//

#ifndef TEXTSCREEN_H
#define TEXTSCREEN_H

#ifdef __cplusplus
//extern "C" { :mad:
#endif

#include "doomkeys.h" // changed from:"../include/doomkeys.h"
#include "TXT_MAIN.H" // changed from:"txt_main.h"

#include "TXT_BU~1.H" // changed from:"txt_button.h"
#include "TXT_CH~1.H" // changed from:"txt_checkbox.h"
#include "TXT_CO~1.H" // changed from:"txt_conditional.h"
#include "TXT_DE~1.H" // changed from:"txt_desktop.h"
#include "TXT_DR~1.H" // changed from:"txt_dropdown.h"
#include "TXT_FI~1.H" // changed from:"txt_fileselect.h"
#include "TXT_IN~1.H" // changed from:"txt_inputbox.h"
#include "TXT_LA~1.H" // changed from:"txt_label.h"
#include "TXT_RA~1.H" // changed from:"txt_radiobutton.h"
#include "TXT_SC~1.H" // changed from:"txt_scrollpane.h"
#include "TXT_SE~1.H" // changed from:"txt_separator.h"
#include "TXT_SP~1.H" // changed from:"txt_spinctrl.h"
#include "TXT_ST~1.H" // changed from:"txt_strut.h"
#include "TXT_TA~1.H" // changed from:"txt_table.h"
#include "TXT_WI~1.H" // changed from:"txt_widget.h"
#include "TXT_WI~3.H" // changed from:"txt_window_action.h"
#include "TXT_WI~2.H" // changed from:"txt_window.h"

#ifdef __cplusplus
//} :mad:
#endif

#endif /* #ifndef TEXTSCREEN_H */

