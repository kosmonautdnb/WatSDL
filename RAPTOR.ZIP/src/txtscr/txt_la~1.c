//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#include <stdlib.h> // changed from:<stdlib.h>
#include <string.h> // changed from:<string.h>

#include "TXT_LA~1.H" // changed from:"txt_label.h"
#include "TXT_GUI.H" // changed from:"txt_gui.h"
#include "TXT_IO.H" // changed from:"txt_io.h"
#include "TXT_MAIN.H" // changed from:"txt_main.h"
#include "TXT_UTF8.H" // changed from:"txt_utf8.h"
#include "TXT_WI~2.H" // changed from:"txt_window.h"

#ifdef _MSC_VER
#define strdup _strdup
#endif

static void TXT_LabelSizeCalc(TXT_UNCAST_ARG(label))
{
    TXT_CAST_ARG(txt_label_t, label);

    label->widget.w = label->w;
    label->widget.h = label->h;
}

static void TXT_LabelDrawer(TXT_UNCAST_ARG(label))
{
    TXT_CAST_ARG(txt_label_t, label);
    unsigned int x, y;
    int origin_x, origin_y;
    unsigned int align_indent = 0;
    unsigned int w, sw;

    w = label->widget.w;

    if (label->bgcolor >= 0)
    {
        TXT_BGColor((txt_color_t)label->bgcolor, 0);
    }
    if (label->fgcolor >= 0)
    {
        TXT_FGColor((txt_color_t)label->fgcolor);
    }

    TXT_GetXY(&origin_x, &origin_y);

    for (y=0; y<label->h; ++y)
    {
        // Calculate the amount to indent this line due to the align
        // setting
        sw = TXT_UTF8_Strlen(label->lines[y]);
        switch (label->widget.align)
        {
            case TXT_HORIZ_LEFT:
                align_indent = 0;
                break;
            case TXT_HORIZ_CENTER:
                align_indent = (label->w - sw) / 2;
                break;
            case TXT_HORIZ_RIGHT:
                align_indent = label->w - sw;
                break;
        }

        // Draw this line

        if (label->customlabel == 1)
            TXT_GotoXY(origin_x + 1, origin_y + y);
        else
            TXT_GotoXY(origin_x, origin_y + y);

        // Gap at the start

        for (x=0; x<align_indent; ++x)
        {
            TXT_DrawString(" ");
        }

        // The string itself

        TXT_DrawString(label->lines[y]);
        x += sw;

        // Gap at the end

        for (; x<w; ++x)
        {
            TXT_DrawString(" ");
        }
    }
}

static void TXT_LabelDestructor(TXT_UNCAST_ARG(label))
{
    TXT_CAST_ARG(txt_label_t, label);

    free(label->label);
    free(label->lines);
}

txt_widget_class_t txt_label_class =
{
    TXT_NeverSelectable,
    TXT_LabelSizeCalc,
    TXT_LabelDrawer,
    NULL,
    TXT_LabelDestructor,
    NULL,
    NULL,
};

void TXT_SetLabel(txt_label_t *label, const char *value)
{
    char *p;
    unsigned int y;

    // Free back the old label

    free(label->label);
    free(label->lines);

    // Set the new value

    label->label = strdup(value);

    // Work out how many lines in this label

    label->h = 1;

    for (p = label->label; *p != '\0'; ++p)
    {
        if (*p == '\n')
        {
            ++label->h;
        }
    }

    // Split into lines

    label->lines = (char**)malloc(sizeof(char *) * label->h);
    label->lines[0] = label->label;
    y = 1;

    for (p = label->label; *p != '\0'; ++p)
    {
        if (*p == '\n')
        {
            label->lines[y] = p + 1;
            *p = '\0';
            ++y;
        }
    }

    label->w = 0;

    for (y=0; y<label->h; ++y)
    {
        unsigned int line_len;

        line_len = TXT_UTF8_Strlen(label->lines[y]);

        if (line_len > label->w)
            label->w = line_len;
    }
}

txt_label_t* TXT_NewSpecialLabel(const char* text)
{
    txt_label_t* label;

    label = (txt_label_t*)malloc(sizeof(txt_label_t));

    TXT_InitWidget(label, &txt_label_class);
    label->label = NULL;
    label->lines = NULL;

    // Default colors

    label->bgcolor = -1;
    label->fgcolor = -1;

    label->customlabel = 1;

    TXT_SetLabel(label, text);

    return label;
}

txt_label_t *TXT_NewLabel(const char *text)
{
    txt_label_t *label;

    label = (txt_label_t*)malloc(sizeof(txt_label_t));

    TXT_InitWidget(label, &txt_label_class);
    label->label = NULL;
    label->lines = NULL;

    // Default colors

    label->bgcolor = -1;
    label->fgcolor = -1;

    label->customlabel = 0;

    TXT_SetLabel(label, text);

    return label;
}

void TXT_SetFGColor(txt_label_t *label, txt_color_t color)
{
    label->fgcolor = color;
}

void TXT_SetBGColor(txt_label_t *label, txt_color_t color)
{
    label->bgcolor = color;
}

