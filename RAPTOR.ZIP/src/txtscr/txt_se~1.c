//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//

#include <stdlib.h> // changed from:<stdlib.h>
#include <string.h> // changed from:<string.h>

#include "TXT_SE~1.H" // changed from:"txt_separator.h"
#include "TXT_GUI.H" // changed from:"txt_gui.h"
#include "TXT_IO.H" // changed from:"txt_io.h"
#include "TXT_MAIN.H" // changed from:"txt_main.h"
#include "TXT_UTF8.H" // changed from:"txt_utf8.h"
#include "TXT_WI~2.H" // changed from:"txt_window.h"

#ifdef _MSC_VER
#define strdup _strdup
#endif

static void TXT_SeparatorSizeCalc(TXT_UNCAST_ARG(separator))
{
    TXT_CAST_ARG(txt_separator_t, separator);

    if (separator->label != NULL)
    {
        // Minimum width is the string length + two spaces for padding

        separator->widget.w = TXT_UTF8_Strlen(separator->label) + 2;
    }
    else
    {
        separator->widget.w = 0;
    }

    separator->widget.h = 1;
}

static void TXT_SeparatorDrawer(TXT_UNCAST_ARG(separator))
{
    TXT_CAST_ARG(txt_separator_t, separator);
    int x, y;
    int w;

    w = separator->widget.w;

    TXT_GetXY(&x, &y);

    // Draw special separator with custom hight, width and color argument else draw standard separator
    // Draw separator.  Go back one character and draw two extra
    // to overlap the window borders.

    if (separator->specialsep == 1)
        TXT_DrawSpecialSeparator(x, y, w + separator->w, separator->h, separator->sepcolor, 1);
    else
        TXT_DrawSeparator(x - 2, y, w + 4, 0, 0);

    if (separator->label != NULL)
    {
        if (separator->specialsep == 1)
        {
            TXT_GotoXY(x + 1, y);

            TXT_FGColor(TXT_COLOR_BRIGHT_GREEN);

            TXT_DrawString(separator->label);
        }
        else
        {
            TXT_GotoXY(x, y);

            TXT_FGColor(TXT_COLOR_BRIGHT_GREEN);

            TXT_DrawString(" ");
            TXT_DrawString(separator->label);
            TXT_DrawString(" ");
        }
    }
}

static void TXT_SeparatorDestructor(TXT_UNCAST_ARG(separator))
{
    TXT_CAST_ARG(txt_separator_t, separator);

    free(separator->label);
}

void TXT_SetSeparatorLabel(txt_separator_t *separator, const char *label)
{
    free(separator->label);

    if (label != NULL)
    {
        separator->label = strdup(label);
    }
    else
    {
        separator->label = NULL;
    }
}

txt_widget_class_t txt_separator_class =
{
    TXT_NeverSelectable,
    TXT_SeparatorSizeCalc,
    TXT_SeparatorDrawer,
    NULL,
    TXT_SeparatorDestructor,
    NULL,
    NULL,
};

txt_separator_t* TXT_NewSpecialSeparator(const char* label, int w, int h, int sepcolor)
{
    txt_separator_t* separator;

    separator = (txt_separator_t*)malloc(sizeof(txt_separator_t));

    separator->sepcolor = sepcolor;
    separator->specialsep = 1;
    separator->w = w;
    separator->h = h;
    
    TXT_InitWidget(separator, &txt_separator_class);

    separator->label = NULL;
    TXT_SetSeparatorLabel(separator, label);

    return separator;
}

txt_separator_t *TXT_NewSeparator(const char *label)
{
    txt_separator_t *separator;

    separator = (txt_separator_t*)malloc(sizeof(txt_separator_t));

    separator->specialsep = 0;

    TXT_InitWidget(separator, &txt_separator_class);

    separator->label = NULL;
    TXT_SetSeparatorLabel(separator, label);

    return separator;
}

