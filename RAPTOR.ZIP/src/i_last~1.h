#pragma once

void I_LASTSCR(char* mem);
