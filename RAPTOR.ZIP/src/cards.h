#pragma once

typedef enum
{
    M_NONE = 0,// 0
    M_PC,      // 1
    M_ADLIB,   // 2
    M_GUS,     // 3
    M_PAS,     // 4
    M_SB,      // 5
    M_WAVE,    // 6
    M_CANVAS,  // 7
    M_GMIDI,   // 8
    M_AWE,     // 9
    M_LAST     // 10
}SCARD;