// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)
#pragma once
#include <_stdint.h> // changed from:<stdint.h>
#include "COMMON.H" // changed from:"common.h"

struct musdevice_t {
    int (*Init)(int option);
    void (*DeInit)(void);
    void (*Mix)(int16_t *stream, int len);
    
    void (*KeyOffEvent)(unsigned int chan, unsigned int key);
    void (*KeyOnEvent)(int chan, unsigned int key, unsigned int volume);
    void (*ControllerEvent)(unsigned int chan, unsigned int controller, unsigned int param);
    void (*PitchBendEvent)(unsigned int chan, int bend);
    void (*ProgramEvent)(unsigned int chan, unsigned int param);
    void (*AllNotesOffEvent)(unsigned int chan, unsigned int param);
};

extern musdevice_t mus_device_opl, mus_device_winmm, mus_device_tsf, mus_device_alsa, mus_device_corea, mus_device_corem;
extern musdevice_t *music_device;


int MUS_Init(int card, int option);
void MUS_DeInit(void);
void MUS_PlaySong(void *ptr, int loop, int fadein);
void MUS_StopSong(int fadeout);
int MUS_SongPlaying(void);
void MUS_Mix(int16_t *stream, int len);
void MUS_Poll(void);
void MUS_SetVolume(int volume);
