//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//    Exit text-mode ENDOOM screen.
//
// Stefan Mader modified this file on 05 November 2025 to compile with WatcomC++11.0  (GPLv2 needs this note)


#include <stdio.h> // changed from:<stdio.h>
#include <string.h> // changed from:<string.h>

#include "RAP.H" // changed from:"rap.h"
#include "I_LAST~1.H" // changed from:"i_lastscr.h"
#include "txtscr\textsc~1.h" // changed from:"textscreen.h"
#include "I_VIDEO.H" // changed from:"i_video.h"
#include "JOYAPI.H" // changed from:"joyapi.h"
#include "KBDAPI.H" // changed from:"kbdapi.h"
#include "PTRAPI.H" // changed from:"ptrapi.h"
#include "IMSAPI.H" // changed from:"imsapi.h"

#define LASTSCR_W 80
#define LASTSCR_H 25


// 
// Displays the text mode ending screen after the game quits
//
void I_LASTSCR(char* mem)
{
    unsigned char* screendata;
    int y;
    int indent;

    TXT_Fullscreen(txt_fullscreen);
    
    // Set up text mode screen

    TXT_Init();

    TXT_SetWindowTitle("Raptor");
    // SDL2-TODO I_InitWindowTitle();
    // SDL2-TODO I_InitWindowIcon();

    // Write the data to the screen memory

    screendata = TXT_GetScreenData();

    indent = (LASTSCR_W - TXT_SCREEN_W) / 2;

    for (y = 0; y < TXT_SCREEN_H; ++y)
    {
        memcpy(screendata + (y * TXT_SCREEN_W * 2),
            mem + (y * LASTSCR_W + indent) * 2,
            TXT_SCREEN_W * 2);
    }

    // Wait for a keypress

    IMS_StartAck();
    I_Settextmode(true);

    while (true)
    {
        TXT_UpdateScreen();
        I_GetEvent();

        if (joy_ack || kbd_ack || mouse_b1_ack || mouse_b2_ack || mouse_b3_ack)
            break;

        TXT_Sleep(0);
    }

    // Shut down text mode screen

    TXT_Shutdown();
}