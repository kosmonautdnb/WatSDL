#include <string.h> // changed from:<string.h>
#include "COMMON.H" // changed from:"common.h"
#include "MOVIE.H" // changed from:"movie.h"
#include "GFXAPI.H" // changed from:"gfxapi.h"
#include "ENTYPES.H" // changed from:"entypes.h"

/*************************************************************************
ANIM_Render () - Renders an ANIM FRAME
 *************************************************************************/
void 
ANIM_Render(
  ANIMLINE *inmem
)
{
  while (LE_USHORT(inmem->opt))
  {
    int l = LE_USHORT(inmem->length);
    int p = LE_USHORT(inmem->offset);
    
    inmem++;
    
    memcpy(&displaybuffer[p], inmem, l);
    
    inmem = (ANIMLINE*)((char*)inmem + l);
  }
}
