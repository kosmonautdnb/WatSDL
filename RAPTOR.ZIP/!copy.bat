copy /Y c:\_OPENGL_\GLIMPL.CPP c:\SDL\SDL2
copy /Y c:\_OPENGL_\GL.H c:\SDL\SDL2
deltree /Y SDL2
mkdir SDL2
copy /Y c:\SDL\SDL2\*.* SDL2
copy /Y c:\_VCODE_\VCODE.EXE
