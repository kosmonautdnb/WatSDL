       ==================================================================
       APOGEE/3D REALMS ORDER FORM - FAX SHEET (Fax number: 972-278-4670)
                                  PAGE 1 OF 2
       ==================================================================

       ** If you don't see your title here, you can write it in below **

[ ] Balls of Steel - 5 Tables including a Duke Table (Win95/98 CD) ($29.95)

[ ] Shadow Warrior CD -- Help Lo Wang kick ass in the far east     ($34.95)
[ ] Duke Nukem 3D: Atomic Edition CD (Plutonium PAK is built in!)  ($49.95)
[ ] Duke Nukem 3D: Plutonium PAK CD - Upgrade v1.3d to Atomic      ($ 4.95)
[ ] Terminal Velocity CD - includes cinematics, etc.               ($39.95)

[ ] Alien Carnage - Technically superb VGA jetpack game            ($19.95)
[ ] Bio Menace - Classic Scroller with Snake Logan!                ($29.95)
[ ] Blake Stone: Aliens of Gold - Futuristic 3D action, 66 levels! ($29.95)
[ ] Boppin' - VGA arcade/puzzle game w/160 levels & level editor!  ($29.95)
[ ] Cosmo's Cosmic Adventure - Help rescue Cosmo's parents         ($34.95)
[ ] Crystal Caves - Help Mylo Steamwitz save his business!         ($34.95)
[ ] Death Rally, Top down 3D racing with combat & gore! (CD Only)  ($ 5.00)
[ ] Duke Nukem I (the original) -- Non-stop pure action!           ($29.95)
[ ] Duke Nukem II -- New VGA explosive action game                 ($34.95)
[ ] Hocus Pocus -- VGA parallaxing platform action/puzzle game!    ($24.95)
[ ] Kroz -- Text based adventure game that started Apogee!         ($24.95)
[ ] Monster Bash - EGA Classic Scroller with a Halloween Theme!    ($34.95)
[ ] Mystic Towers -- Totally unique action/puzzle game!            ($24.95)
[ ] Paganitzu - CGA/EGA puzzle game - One of our best puzzle games ($29.95)
[ ] Planet Strike -- 3D Action, sequel to original Blake Stone     ($24.95)
[ ] Raptor: Call of the Shadows - Best VGA shooter ever on the PC! ($34.95)
[ ] Realms of Chaos, Disk or CD-ROM Version - VGA arcade/action!   ($24.95)
[ ] Rise of the Triad, CD-ROM Version - Includes PowerPack         ($34.95)
[ ] Rise of the Triad, Site License CDROM Version Save up to $295! ($89.95)
[ ] Secret Agent - You're 007 1/2 - Save the world from DVS!       ($29.95)
[ ] Stargunner CD - The new Standard in PC Shooters!               ($29.95)
[ ] Wacky Wheels CD - Upgrade Edition With 42 total tracks!        ($34.95)
[ ] Wolfenstein 3-D All SIX EPISODES "Wolf-Pack"                   ($49.95)
[ ] Wolfenstein 3-D Hint Book (with all maps, story and secrets)   ($10.00)
[ ] Xenophage CD - Fierce Fighting Fun                             ($ 5.00)

          *** THE FOLLOWING COMBO OFFERS WILL SAVE YOU BIG BUCKS! ***

[ ] Commander Keen: Vorticons/Galaxy Combo - CD Only               ($49.95)
[ ] Word Rescue & Math Rescue Combo - CD Only                      ($39.95)
[ ] Death Rally & Xenophage Combo - CD Only                        ($ 8.00)

                        *** MISCELLEANOUS ITEMS ***

[ ] Duke Nukem 3D Strategy Guide Book                              ($ 4.95)
[ ] Duke Nukem 3D Mouse Pad                                        ($ 2.50)
[ ] T-Shirt: Apogee Logo (White) (M,L,XXL)                         ($ 5.95)
[ ] T-Shirt: Monster Bash (White) (M,L,XL,XXL)                     ($ 5.95)
[ ] T-Shirt: Wolfenstein 3D (White) (S,M,L,XXL)                    ($ 5.95)

[ ] other _________________________________________________________________

                             --- continued ---

     ==================================================================
     APOGEE SOFTWARE ORDER FORM - FAX SHEET  (Fax number: 972-278-4670)
                                PAGE 2 OF 2
     ==================================================================

Name (please print)________________________________________________________

Address ___________________________________________________________________

Address ___________________________________________________________________

City _______________________ St./Prov. _________________ ZIP/Code _________

Country (if not USA) ____________________ Phone/Fax _______________________

E-Mail ____________________________________________________________________

DISK SIZE: [ ] 3.5" 1.44M  [ ] 3.5" 720K  [ ] 5.25" 1.2M [ ] CD-ROM
           (Please check all that you can use - we will send the highest 
            available format.)

SHIPPING [ ] USA: $5. Each additional item add $1.
CHARGES: [ ] Canada & Mexico: $6. Each additional item add $1.
         [ ] All other countries: $8. Each addtl. item add $2; shirts $4.

If this is being shipped to TX, you must add 8.25% sales tax to total order.

Total payment: $______________  

Payment: [ ] Visa [ ] MasterCard [ ] Discover [ ] American Express
         [ ] Check [ ] Money Order

Card number: ______________________________________________________________

Expiration date: _____/_____ (MM/YY)  Signature: __________________________

Note: Payment must be in U.S. dollars and drawn against a U.S. bank.
      Please do not send cash!

Mail to:  Apogee Software, Ltd.      Order: 1-800-APOGEE1  (1-800-276-4331)
          P.O. Box 496389            Phone: (972) 278-5655 (Foreign orders)
          Garland, TX 75049-6389     Visa, MasterCard, Discover welcome!

Thank you for your order!  Make checks payable to "Apogee".  Allow up to
two weeks for delivery.  All prices subject to change without notice.
All items subject to availability.

For more ordering info, and for specials not listed here, please visit our
order info page on the web at http://www.apogee1.com/misc/order.html.

Thank you!
