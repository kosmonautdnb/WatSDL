call !copy.bat
call !clean.bat
call !make.bat
copy r:\main.exe raptor.exe
del raptor.zip
zip raptor.zip raptor.exe *.glb *.ini !*.* -r src\*.* _build\*.* sdl2\*.* raptor\*.*
